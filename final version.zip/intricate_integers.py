import math

class IntricateIntegers:
    def __init__(self, obj, modulus, alpha=None):
        if alpha == None:
            self.value = 0
            self.modulus = obj
            self.alpha = modulus
        else:
            self.value = obj
            self.modulus = modulus
            self.alpha = alpha
        ##self.elements = [IntricateInteger(i, modulus, alpha) for i in range(modulus)]

    def __str__(self):
        ##return "{"+(", ".join(str(element) for element in self.elements))+"}"
        #return "v="+str(self.value)+" m= "+str(self.modulus)+" a= "+str(self.alpha)
        return str(self.value) + " mod "+str(self.modulus)+" | "+str(self.alpha)
    def __repr__(self):
        # This makes the __repr__ method return the same string as __str__
        return self.__str__()
    def size(self):
        return self.modulus
    def __mul__(self,other):
        if self.modulus != other.modulus:
            raise ValueError
        if self.alpha != other.alpha:
            raise ValueError
        obj = (self.value+other.value + self.alpha * math.lcm(self.value,other.value)) % self.modulus
        return IntricateIntegers(obj,self.modulus,self.alpha)
    def __iter__(self):
        from intricate_integer_hardfeatures import IntricateIntegerIterator
        return IntricateIntegerIterator(self.value, self.modulus, self.alpha)
    def __eq__(self, other):
        # Check if 'other' is instance of MyClass and compare values
        return isinstance(other, IntricateIntegers) and self.value == other.value and self.modulus == other.modulus and self.alpha == other.alpha 

    def __hash__(self):
        # Hash the value for set comparisons
        return hash(self.value)