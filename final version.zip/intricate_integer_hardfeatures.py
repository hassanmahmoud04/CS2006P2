import math
from intricate_integers import IntricateIntegers
from intricate_integers_iterator import IntricateIntegerIterator
from itertools import combinations


# check whether or not x ⊗ x = x holds for all x ∈ Zn
def iterator_has_intricate_peculiar_property(n,alpha):
    for elem in IntricateIntegers(n,alpha):
        if (elem * elem).value != elem.value:
            return False
    return True


# check whether or not x ⊗ y = y ⊗ x  holds for all x ∈ Zn
def iterator_has_commutative_intricate_multiplication(n,alpha):
    # Iterate and print the value of n for each new instance of A
    for elem in IntricateIntegers(n,alpha):
        for elem2 in elem:
            if (elem * elem2).value != (elem2 * elem).value:
                return False
    return True

# New feature: Check associative property
def has_associative_intricate_multiplication(n, alpha):
    for x in IntricateIntegers(n,alpha):
        for y in x:
            for z in y:
                if not (((x * y) * z).value == (x * (y * z)).value):
                    return False
    return True

# New feature: Find intricate roots of one
def intricate_roots_of_one(n, alpha):
    roots = []
    for x in range(n):
        elem = IntricateIntegers(x, n, alpha)
        if (elem * elem).value == IntricateIntegers(1, n, alpha).value:
            roots.append(elem)
    return roots

def all_product_combos(generators):
    # Initialize an empty list to store all combinations
    all_combinations = []
    product_combo = set()

    # Generate combinations for every possible length
    for r in range(1, len(generators) + 1):
        # Extend the list with combinations of the current length
        all_combinations.extend(combinations(generators, r))
    for d in all_combinations:
        if len(d) > 1:
            product = d[0]

            for i in range(1,len(d)):
                m = d[i]
                product = product * m
            product_combo.add(product)
    return product_combo




