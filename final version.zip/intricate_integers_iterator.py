import math
from intricate_integers import IntricateIntegers
from itertools import combinations


class IntricateIntegerIterator:
    def __init__(self, current, n=None , alpha=None):
        #if isinstance(current,IntricateIntegers):
            #self.current = current.value
            #self.end = current.modulus
            #self.alpha = current.alpha
        #if isinstance(current,IntricateIntegerIterator):
            #self.current = current.current
            #self.end = current.end
            #self.alpha = current.alpha
        #else:
        self.current = current  # Start iteration from 0
        self.end = n  # End of iteration defined by n
        self.alpha = alpha
    #def __iter__(self):

        #return self

    def __next__(self):
        if self.current < self.end:
            # Create a new instance of A for the current value
            instance = IntricateIntegers(self.current,self.end,self.alpha)
            self.current += 1
            return instance
        else:
            raise StopIteration
