from intricate_integer_hardfeatures import iterator_has_intricate_peculiar_property, iterator_has_commutative_intricate_multiplication, has_associative_intricate_multiplication, intricate_roots_of_one, all_product_combos
from intricate_integers import IntricateIntegers
import math

# check for all pairs (n, α), where 1 ≤ n ≤ 50 and 0 ≤ α < n, that this property holds if and only if α = n − 1.
def test_peculiar_property(peculiarity_results):
    for n, a in peculiarity_results:
        if a != n-1:
            print("Test failed: property does not hold for",(n, a))
            return
    print("Test passed! property holds if and only if α = n − 1")
def test_commutitive_and_peculiar_property():

    peculiar_property_results = []
    commutative_property_results = []
    print(IntricateIntegers(5,6,2))
    for n in range(1, 51):
        peculiar_property_results += [(n, a) for a in range(0, n) if iterator_has_intricate_peculiar_property(n, a)]
        commutative_property_results += [(n, a) for a in range(0, n) if not iterator_has_commutative_intricate_multiplication(n, a)]
    print("test_peculiar_property")
    test_peculiar_property(peculiar_property_results)
    print("Pairs (n, alpha) where commutativity does not hold:", commutative_property_results)


test_commutitive_and_peculiar_property()
def test_associative_property():
    
    # Testing new features
    print("Testing associative property and intricate roots of one...")
    numtrue = 0
    numfalse = 0
    roots = []
    for n in range(1, 5): # Example range, adjust as needed
        for alpha in range(0, n):
            roots = intricate_roots_of_one(n, alpha)
            for r in roots:
                prod = r*r
                if prod.value != 1:
                    print("Found root failed",r,prod)

            if has_associative_intricate_multiplication(n,alpha):
                numtrue = numtrue +1
            else:
                numfalse = numfalse +1
            #print(f"n={n}, alpha={alpha}, associative: {has_associative_intricate_multiplication(n, alpha)}")
            #print(f"n={n}, alpha={alpha}, roots of one: {intricate_roots_of_one(n, alpha)}")
    print("Number of true "+ str(numtrue) + " Number of false " + str(numfalse))
    print(roots)

def test_exceptions():
    x = IntricateIntegers(3,8,2)
    y = IntricateIntegers(3,7,2)
    z = IntricateIntegers(4,8,3)
    try:

        x*y
        print("Failed to raise exception")

    except ValueError:
        print("Received expected exception")
    try:
        x*z
        print("Failed to raise exception")
    except ValueError:
        print("Received expected exception")


def test_product_combos():

    # Example set of numbers
    numbers = [IntricateIntegers(1,5,2), IntricateIntegers(2,5,2), IntricateIntegers(3,5,2)]

    # Generate all combinations
    combinations_result = all_product_combos(numbers)

    # Convert tuple combinations to list and print the result
    print(combinations_result)

    numbers.append(IntricateIntegers(1,5,2))
    combinations_result = all_product_combos(numbers)
    # Convert tuple combinations to list and print the result
    print(combinations_result)
    try:
        numbers.append(IntricateIntegers(1,4,2))
        combinations_result = all_product_combos(numbers)
        # Convert tuple combinations to list and print the result
        print(combinations_result)
    except ValueError:
        print("Received expected exception")
    try:
        numbers[len(numbers)-1]=(IntricateIntegers(1,5,3))
        print(numbers)
        combinations_result = all_product_combos(numbers)
        # Convert tuple combinations to list and print the result
        print(combinations_result)
    except ValueError:
        print("Received expected exception")

def main():
    test_commutitive_and_peculiar_property()
    test_associative_property()
    print(IntricateIntegers(3,8,2).size())
    test_exceptions()
    test_product_combos()
if __name__ == "__main__":
    main()